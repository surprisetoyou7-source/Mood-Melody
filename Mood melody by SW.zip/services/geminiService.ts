import { GoogleGenAI, Type } from "@google/genai";
import { Mood } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const detectMoodFromImage = async (base64Image: string): Promise<Mood> => {
  try {
    // Clean the base64 string if it contains the header
    const cleanBase64 = base64Image.replace(/^data:image\/(png|jpeg|jpg);base64,/, "");

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          inlineData: {
            mimeType: "image/jpeg",
            data: cleanBase64
          }
        },
        {
          text: `Analyze the facial expression of the person in this photo. 
          Classify their mood into exactly one of the following categories: 
          "Happy", "Sad", "Calm", "Energetic", "Surprised", "Neutral".
          
          If you are unsure or no face is clearly visible, default to "Neutral".
          Return only the JSON object.`
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            mood: {
              type: Type.STRING,
              enum: [
                "Happy", "Sad", "Calm", "Energetic", "Surprised", "Neutral"
              ]
            },
            confidence: {
              type: Type.NUMBER,
              description: "Confidence level between 0 and 1"
            }
          },
          required: ["mood"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    
    // Validate that the returned mood is a valid Mood enum value
    const moodString = result.mood as string;
    if (Object.values(Mood).includes(moodString as Mood)) {
      return moodString as Mood;
    }
    
    return Mood.NEUTRAL;

  } catch (error) {
    console.error("Gemini API Error:", error);
    // Fallback in case of error
    return Mood.NEUTRAL;
  }
};
