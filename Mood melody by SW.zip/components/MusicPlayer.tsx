import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, SkipForward, SkipBack, Heart, MoreHorizontal, Repeat, Shuffle } from 'lucide-react';
import { Track } from '../types';

interface MusicPlayerProps {
  track: Track;
  isPlaying: boolean;
  onPlayPause: () => void;
  onNext: () => void;
  onPrev: () => void;
}

const MusicPlayer: React.FC<MusicPlayerProps> = ({ track, isPlaying, onPlayPause, onNext, onPrev }) => {
  const [progress, setProgress] = useState(0);
  const progressRef = useRef<number>(0);

  // Mock progress simulation
  useEffect(() => {
    let interval: number;
    if (isPlaying) {
      interval = window.setInterval(() => {
        setProgress((prev) => {
          const next = prev + 1;
          if (next >= track.duration) {
             onNext();
             return 0;
          }
          return next;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, track.duration, onNext]);

  // Reset progress on track change
  useEffect(() => {
    setProgress(0);
  }, [track.id]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const progressPercent = (progress / track.duration) * 100;

  return (
    <div className="flex flex-col h-full justify-end pb-8">
      {/* Album Art */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className={`relative w-full aspect-square max-w-sm rounded-2xl shadow-2xl overflow-hidden transition-transform duration-700 ${isPlaying ? 'scale-100' : 'scale-95 opacity-90'}`}>
          <img 
            src={track.coverUrl} 
            alt={track.title} 
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Track Info */}
      <div className="px-8 mb-6">
        <div className="flex justify-between items-center mb-1">
          <div>
            <h2 className="text-2xl font-bold text-white leading-tight line-clamp-1">{track.title}</h2>
            <p className="text-white/60 text-lg line-clamp-1">{track.artist}</p>
          </div>
          <button className="text-white/60 hover:text-green-400 transition-colors">
            <Heart size={28} />
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="px-8 mb-6">
        <div className="w-full bg-white/10 h-1.5 rounded-full mb-2 cursor-pointer group">
          <div 
            className="bg-white h-full rounded-full relative transition-all duration-300 ease-linear"
            style={{ width: `${progressPercent}%` }}
          >
             <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>
        <div className="flex justify-between text-xs text-white/40 font-medium">
          <span>{formatTime(progress)}</span>
          <span>{formatTime(track.duration)}</span>
        </div>
      </div>

      {/* Controls */}
      <div className="px-8 flex items-center justify-between">
        <button className="text-white/40 hover:text-white transition-colors">
          <Shuffle size={20} />
        </button>
        
        <button onClick={onPrev} className="text-white hover:text-white/80 transition-colors">
          <SkipBack size={32} fill="currentColor" />
        </button>
        
        <button 
          onClick={onPlayPause}
          className="w-16 h-16 bg-white rounded-full flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-lg text-black"
        >
          {isPlaying ? (
            <Pause size={32} fill="currentColor" />
          ) : (
            <Play size={32} fill="currentColor" className="ml-1" />
          )}
        </button>
        
        <button onClick={onNext} className="text-white hover:text-white/80 transition-colors">
          <SkipForward size={32} fill="currentColor" />
        </button>
        
        <button className="text-white/40 hover:text-white transition-colors">
          <Repeat size={20} />
        </button>
      </div>
    </div>
  );
};

export default MusicPlayer;